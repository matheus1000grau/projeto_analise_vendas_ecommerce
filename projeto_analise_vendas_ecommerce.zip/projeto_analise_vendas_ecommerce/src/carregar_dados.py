"""Carrega o CSV de exemplo para dbo.Vendas."""
from pathlib import Path
import pandas as pd
from sqlalchemy import text
from config import criar_engine

RAIZ = Path(__file__).resolve().parents[1]
ARQUIVO = RAIZ / "data" / "vendas_ecommerce.csv"

def main():
    dados = pd.read_csv(ARQUIVO, parse_dates=["order_date"])
    engine = criar_engine()

    # Evita duplicação quando o script é executado mais de uma vez.
    with engine.begin() as conexao:
        conexao.execute(text("DELETE FROM dbo.Vendas"))

    dados.to_sql(
        "Vendas",
        con=engine,
        schema="dbo",
        if_exists="append",
        index=False,
        chunksize=100,
        method="multi",
    )
    print(f"Carregamento concluído: {len(dados)} linhas inseridas em dbo.Vendas.")

if __name__ == "__main__":
    main()
