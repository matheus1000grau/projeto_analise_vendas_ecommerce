"""Configuração da conexão com SQL Server via variáveis de ambiente."""
import os
from urllib.parse import quote_plus
from sqlalchemy import create_engine

def criar_engine():
    servidor = os.getenv("SQL_SERVER", r"localhost")
    banco = os.getenv("SQL_DATABASE", "EcommerceVendas")
    driver = os.getenv("SQL_DRIVER", "ODBC Driver 18 for SQL Server")
    usuario = os.getenv("SQL_USER")
    senha = os.getenv("SQL_PASSWORD")
    confiar_certificado = os.getenv("SQL_TRUST_CERT", "yes")

    if usuario and senha:
        odbc = (
            f"DRIVER={{{driver}}};SERVER={servidor};DATABASE={banco};"
            f"UID={usuario};PWD={senha};TrustServerCertificate={confiar_certificado};"
        )
    else:
        # Autenticação integrada do Windows; funciona em ambientes Windows configurados.
        odbc = (
            f"DRIVER={{{driver}}};SERVER={servidor};DATABASE={banco};"
            "Trusted_Connection=yes;"
            f"TrustServerCertificate={confiar_certificado};"
        )
    return create_engine("mssql+pyodbc:///?odbc_connect=" + quote_plus(odbc))
