"""Executa consultas SQL e salva gráficos simples na pasta outputs/."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
from sqlalchemy import text
from config import criar_engine

RAIZ = Path(__file__).resolve().parents[1]
PASTA_SAIDA = RAIZ / "outputs"
PASTA_SAIDA.mkdir(exist_ok=True)

def consultar(engine, sql):
    return pd.read_sql(text(sql), engine)

def main():
    engine = criar_engine()

    resumo = consultar(engine, """
        SELECT
            COUNT(DISTINCT order_id) AS total_pedidos,
            COUNT(DISTINCT customer_id) AS clientes_unicos,
            SUM(CASE WHEN status = N'Entregue'
                THEN quantity * unit_price * (1 - discount_pct) ELSE 0 END) AS receita_liquida,
            SUM(CASE WHEN status = N'Entregue' THEN quantity ELSE 0 END) AS unidades_vendidas
        FROM dbo.Vendas;
    """)
    resumo.to_csv(PASTA_SAIDA / "resumo_geral.csv", index=False, encoding="utf-8-sig")
    print("\\n=== RESUMO GERAL ===")
    print(resumo.to_string(index=False, formatters={"receita_liquida": "R$ {:,.2f}".format}))

    mensal = consultar(engine, """
        SELECT DATEFROMPARTS(YEAR(order_date), MONTH(order_date), 1) AS mes,
               SUM(quantity * unit_price * (1 - discount_pct)) AS receita
        FROM dbo.Vendas
        WHERE status = N'Entregue'
        GROUP BY DATEFROMPARTS(YEAR(order_date), MONTH(order_date), 1)
        ORDER BY mes;
    """)
    mensal.to_csv(PASTA_SAIDA / "receita_mensal.csv", index=False, encoding="utf-8-sig")
    plt.figure(figsize=(10, 5))
    plt.plot(pd.to_datetime(mensal["mes"]), mensal["receita"], marker="o")
    plt.title("Receita líquida por mês")
    plt.xlabel("Mês")
    plt.ylabel("Receita (R$)")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(PASTA_SAIDA / "receita_mensal.png", dpi=150)
    plt.close()

    categorias = consultar(engine, """
        SELECT category,
               SUM(quantity * unit_price * (1 - discount_pct)) AS receita
        FROM dbo.Vendas
        WHERE status = N'Entregue'
        GROUP BY category
        ORDER BY receita DESC;
    """)
    categorias.to_csv(PASTA_SAIDA / "receita_categoria.csv", index=False, encoding="utf-8-sig")
    plt.figure(figsize=(9, 5))
    plt.bar(categorias["category"], categorias["receita"])
    plt.title("Receita por categoria")
    plt.xlabel("Categoria")
    plt.ylabel("Receita (R$)")
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    plt.savefig(PASTA_SAIDA / "receita_categoria.png", dpi=150)
    plt.close()

    produtos = consultar(engine, """
        SELECT TOP 10 product_name,
               SUM(quantity * unit_price * (1 - discount_pct)) AS receita
        FROM dbo.Vendas
        WHERE status = N'Entregue'
        GROUP BY product_name
        ORDER BY receita DESC;
    """)
    produtos.to_csv(PASTA_SAIDA / "top_produtos.csv", index=False, encoding="utf-8-sig")

    print("\\nArquivos gerados na pasta outputs/:")
    print("- resumo_geral.csv")
    print("- receita_mensal.csv e receita_mensal.png")
    print("- receita_categoria.csv e receita_categoria.png")
    print("- top_produtos.csv")

if __name__ == "__main__":
    main()
