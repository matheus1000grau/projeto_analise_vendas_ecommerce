# Dicionário de dados

Cada linha representa um item de um pedido.

| Campo | Descrição |
|---|---|
| order_id | Identificador do pedido |
| order_date | Data do pedido |
| customer_id | Identificador fictício do cliente |
| product_id | Identificador do produto |
| product_name | Nome do produto |
| category | Categoria do produto |
| quantity | Quantidade de unidades no item |
| unit_price | Preço unitário em reais |
| discount_pct | Desconto em decimal (0.10 = 10%) |
| payment_method | Meio de pagamento |
| state | UF de destino |
| status | Status do pedido |
