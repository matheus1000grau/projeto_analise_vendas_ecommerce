# Análise de Vendas de E-commerce | SQL Server + Python

Projeto de portfólio para iniciantes em **Análise de Dados**, usando SQL Server para armazenar e consultar dados e Python para gerar relatórios e gráficos.

> **Dados fictícios:** o CSV incluído foi criado para fins de estudo. Não representa uma loja real nem clientes reais.

## Objetivos

- Carregar dados de vendas em uma tabela SQL Server.
- Praticar consultas SQL com `GROUP BY`, `SUM`, `COUNT`, `CASE` e `ORDER BY`.
- Analisar receita por mês, categoria e produto.
- Gerar CSVs e gráficos com Python, Pandas e Matplotlib.

## Perguntas de negócio

1. Qual foi a receita líquida dos pedidos entregues?
2. Como a receita variou ao longo dos meses?
3. Quais categorias e produtos geraram mais receita?
4. Quais meios de pagamento foram mais usados?
5. Quantos pedidos estão entregues, cancelados ou em processamento?

## Estrutura do projeto

```text
projeto_analise_vendas_ecommerce/
├── data/
│   └── vendas_ecommerce.csv
├── sql/
│   ├── 01_criar_banco.sql
│   ├── 02_criar_tabela.sql
│   └── 03_consultas_analise.sql
├── src/
│   ├── config.py
│   ├── carregar_dados.py
│   └── analise_vendas.py
├── outputs/
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## Tecnologias

- Microsoft SQL Server
- SQL Server Management Studio (SSMS)
- Python 3.10+
- Pandas
- SQLAlchemy + pyodbc
- Matplotlib

## Como executar

### 1. Instale os pré-requisitos

Instale o SQL Server (Developer ou Express), o SSMS, Python 3.10+ e o **Microsoft ODBC Driver 18 for SQL Server**.

### 2. Crie o banco e a tabela

Abra o SSMS e conecte-se ao seu servidor.

1. Abra e execute `sql/01_criar_banco.sql`.
2. Abra e execute `sql/02_criar_tabela.sql`.

**Atenção:** o script `02_criar_tabela.sql` apaga e recria `dbo.Vendas` se ela já existir. Use-o apenas neste projeto de estudo ou faça backup antes.

### 3. Prepare o ambiente Python

No terminal, entre na pasta do projeto e execute:

```bash
python -m venv .venv
```

No Windows:

```powershell
.venv\Scripts\Activate.ps1
```

No macOS/Linux:

```bash
source .venv/bin/activate
```

Instale as bibliotecas:

```bash
pip install -r requirements.txt
```

### 4. Configure a conexão

Por padrão, `src/config.py` tenta conectar a `localhost`, banco `EcommerceVendas`, usando autenticação integrada do Windows.

Se seu servidor tiver outro nome, configure as variáveis de ambiente antes de executar. Exemplo no PowerShell:

```powershell
$env:SQL_SERVER="localhost"
$env:SQL_DATABASE="EcommerceVendas"
$env:SQL_DRIVER="ODBC Driver 18 for SQL Server"
```

Se usar autenticação SQL, configure também `SQL_USER` e `SQL_PASSWORD`. Não publique senhas no GitHub. O arquivo `.env.example` é apenas um modelo; o código não carrega automaticamente um arquivo `.env`.

### 5. Carregue o CSV

Execute a partir da pasta raiz do projeto:

```bash
python src/carregar_dados.py
```

O script limpa a tabela `dbo.Vendas` antes de inserir o CSV para evitar duplicação. Portanto, ele é adequado para este conjunto de estudo, não para um sistema de produção.

### 6. Execute a análise

```bash
python src/analise_vendas.py
```

Os resultados são gravados na pasta `outputs/`:

- `resumo_geral.csv`
- `receita_mensal.csv` e `receita_mensal.png`
- `receita_categoria.csv` e `receita_categoria.png`
- `top_produtos.csv`

Você também pode executar `sql/03_consultas_analise.sql` no SSMS para praticar SQL diretamente.

## Regra de negócio usada

A receita é calculada como:

`quantidade × preço unitário × (1 − desconto)`

Neste projeto, **somente pedidos com status `Entregue` entram no cálculo de receita e unidades vendidas**. A contagem geral de pedidos e clientes inclui todos os status. Cada linha do CSV representa um item de pedido; por isso usamos `COUNT(DISTINCT order_id)` para contar pedidos.

## Ideias para evoluir o projeto

- Criar uma tabela calendário e dimensões de produtos e clientes.
- Calcular ticket médio: receita líquida ÷ quantidade de pedidos entregues.
- Criar uma taxa de cancelamento.
- Adicionar testes de qualidade dos dados.
- Criar um dashboard no Power BI.
- Automatizar a atualização dos dados.

## Como apresentar no GitHub

Sugestão de descrição do repositório:

> Projeto iniciante de análise de vendas de e-commerce com SQL Server e Python. Inclui carga de dados fictícios, consultas SQL para indicadores de negócio e geração de relatórios e gráficos com Pandas e Matplotlib.

Sugestão de nome do repositório: `analise-vendas-ecommerce-sql-python`

## Possíveis dificuldades

- **Erro de driver ODBC:** confirme que o ODBC Driver 18 está instalado.
- **Erro de conexão:** confira o nome do servidor em `SQL_SERVER`, se o serviço SQL Server está ativo e se a autenticação está habilitada.
- **Erro de login:** verifique se está usando autenticação integrada ou SQL corretamente.
- **Permissão negada:** o usuário precisa ter permissão para inserir e consultar dados no banco.
