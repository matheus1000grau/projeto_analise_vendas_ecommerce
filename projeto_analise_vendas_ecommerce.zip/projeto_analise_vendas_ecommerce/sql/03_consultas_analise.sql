USE EcommerceVendas;
GO

-- 1. Indicadores gerais. Receita considera apenas pedidos entregues.
SELECT
    COUNT(DISTINCT order_id) AS total_pedidos,
    COUNT(DISTINCT customer_id) AS clientes_unicos,
    SUM(CASE WHEN status = N'Entregue'
        THEN quantity * unit_price * (1 - discount_pct) ELSE 0 END) AS receita_liquida,
    SUM(CASE WHEN status = N'Entregue' THEN quantity ELSE 0 END) AS unidades_vendidas
FROM dbo.Vendas;
GO

-- 2. Receita por mês
SELECT
    FORMAT(order_date, 'yyyy-MM') AS mes,
    SUM(quantity * unit_price * (1 - discount_pct)) AS receita
FROM dbo.Vendas
WHERE status = N'Entregue'
GROUP BY FORMAT(order_date, 'yyyy-MM')
ORDER BY mes;
GO

-- 3. Produtos com maior receita
SELECT TOP 10
    product_name,
    SUM(quantity * unit_price * (1 - discount_pct)) AS receita
FROM dbo.Vendas
WHERE status = N'Entregue'
GROUP BY product_name
ORDER BY receita DESC;
GO

-- 4. Desempenho por categoria
SELECT
    category,
    SUM(quantity) AS unidades,
    SUM(quantity * unit_price * (1 - discount_pct)) AS receita
FROM dbo.Vendas
WHERE status = N'Entregue'
GROUP BY category
ORDER BY receita DESC;
GO

-- 5. Métodos de pagamento mais usados
SELECT payment_method, COUNT(DISTINCT order_id) AS pedidos
FROM dbo.Vendas
GROUP BY payment_method
ORDER BY pedidos DESC;
GO

-- 6. Pedidos por status
SELECT status, COUNT(DISTINCT order_id) AS pedidos
FROM dbo.Vendas
GROUP BY status
ORDER BY pedidos DESC;
GO
