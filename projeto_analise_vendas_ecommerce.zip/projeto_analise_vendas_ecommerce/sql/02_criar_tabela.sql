USE EcommerceVendas;
GO

IF OBJECT_ID('dbo.Vendas', 'U') IS NOT NULL
    DROP TABLE dbo.Vendas;
GO

CREATE TABLE dbo.Vendas (
    venda_item_id INT IDENTITY(1,1) PRIMARY KEY,
    order_id VARCHAR(20) NOT NULL,
    order_date DATE NOT NULL,
    customer_id VARCHAR(20) NOT NULL,
    product_id VARCHAR(10) NOT NULL,
    product_name NVARCHAR(100) NOT NULL,
    category NVARCHAR(50) NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(10,2) NOT NULL CHECK (unit_price >= 0),
    discount_pct DECIMAL(4,2) NOT NULL CHECK (discount_pct BETWEEN 0 AND 1),
    payment_method NVARCHAR(50) NOT NULL,
    state CHAR(2) NOT NULL,
    status NVARCHAR(30) NOT NULL
);
GO

CREATE INDEX IX_Vendas_OrderDate ON dbo.Vendas(order_date);
CREATE INDEX IX_Vendas_Category ON dbo.Vendas(category);
GO
