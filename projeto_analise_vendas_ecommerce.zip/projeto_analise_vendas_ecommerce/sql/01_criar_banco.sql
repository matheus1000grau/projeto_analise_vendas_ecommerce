-- Execute este script no SQL Server Management Studio (SSMS).
IF DB_ID('EcommerceVendas') IS NULL
    CREATE DATABASE EcommerceVendas;
GO
